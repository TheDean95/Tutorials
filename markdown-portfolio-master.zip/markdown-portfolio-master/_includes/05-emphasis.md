Programming Skill *R*
Programming Skill **Python**

*SQL* and **VBA**
