![Image of Yaktocat](https://octodex.github.com/images/yaktocat.png)
